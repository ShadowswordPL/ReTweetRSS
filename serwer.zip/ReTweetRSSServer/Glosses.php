<?php

     include "start.php";
      
     echo "<glosses>";
     
     $positives = "";
     if(!is_true(positive))
     {
         $positives = " AND gloss.ispositive <> TRUE ";
     }
     
     $negatives = "";
     if(!is_true(negative))
     {
         $negatives = " AND gloss.ispositive <> FALSE ";
     }
     
     $order = "usedby desc";
     switch(safe_get(sort))
     {
         case "popasc":
             $order = "usedby asc";
             break;
         case "alpasc":
             $order = "content asc";
             break;
         case "alpdesc":
             $order = "content desc";
             break;
     }
      
     $query = '(
                    SELECT 
                        gloss.id, gloss.content, gloss.ispositive, count(*) as usedby, 1 as selected
                    FROM 
                        "gloss" 
                    RIGHT JOIN 
                        "usergloss" 
                    ON 
                        "id" = "gloss_id" 
                    WHERE
                        gloss_id 
                    IN
                    (
                        SELECT 
                            gloss.id
                        FROM 
                            "gloss" 
                        RIGHT JOIN 
                            "usergloss" 
                        ON 
                            "id" = "gloss_id" 
                        WHERE 
                            user_id = '.$user[id].'
                   )
                   GROUP BY 
                        gloss.id, gloss.content, gloss.ispositive
                   HAVING
                        gloss.id > 0 
                        '.$positives.$negatives.'
               )
               
               UNION
               
               (
                    SELECT 
                        gloss.id, gloss.content, gloss.ispositive, count(*) as usedby, 0 as selected
                    FROM 
                        "gloss" 
                    RIGHT JOIN 
                        "usergloss"
                    ON 
                        "id" = "gloss_id" 
                    WHERE
                        gloss.id     
                    NOT IN
                    (
                        SELECT 
                            gloss.id
                        FROM 
                            "gloss" 
                        RIGHT JOIN 
                            "usergloss" 
                        ON 
                            "id" = "gloss_id" 
                        WHERE 
                            user_id = '.$user[id].'
                   )
                   GROUP BY 
                        gloss.id, gloss.content, gloss.ispositive
                   HAVING
                        gloss.id > 0 
                        '.$positives.$negatives.'
               )
               
               UNION
               
               (
                    SELECT 
                        gloss.id, gloss.content, gloss.ispositive, 0 as usedby, 0 as selected
                    FROM 
                        "gloss" 
                    WHERE
                        id 
                    NOT IN
                    (
                        SELECT 
                            gloss_id
                        FROM
                             "usergloss"
                    )
                    '.$positives.$negatives.'
               )
               ORDER BY selected desc, '.$order.'
               ;';
     $result = pg_query($query) or fail();
         
     while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) 
     {
        echo "<gloss>";
        echo "<id>$line[id]</id>";
        echo "<content>$line[content]</content>";
        if($line[ispositive] == "t")
        {
            $pos = 1;
        }
        else
        {
            $pos = 0;
        }
        echo "<isPositive>$pos</isPositive>";
        echo "<selected>$line[selected]</selected>";
        echo "<usedby>$line[usedby]</usedby>";
        echo "</gloss>";
     }
         
     echo "</glosses>";
     
     include "end.php";
?>
