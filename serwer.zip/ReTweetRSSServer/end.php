<?php
    echo "</xml>";
    
    pg_free_result($result);
    pg_close($con);
?>
