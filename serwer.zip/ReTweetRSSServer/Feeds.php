<?php

     include "start.php";
     
     $query = 'SELECT * FROM "feed" WHERE "user_id" = '.$user["id"];
     $result = pg_query($query) or fail();
     
     echo "<feeds>";
     while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) 
     {
         echo "<feed>";
         echo "<id>$line[id]</id>";
         echo "<name>$line[name]</name>";
         echo "<link>$line[link]</link>";
         echo "</feed>";
     }
     echo "</feeds>";
     
     include "end.php";
?>
