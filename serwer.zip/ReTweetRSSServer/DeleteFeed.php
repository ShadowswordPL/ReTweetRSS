<?php

    include "start.php";
    
    $query = 'DELETE FROM "feed"
              WHERE
                "id" = '.safe_get("ID").'
              ;';  
    $result = pg_query($query) or fail();
    
    echo "<success>1</success>";
    
    include "end.php";
?>
