<?php

     include "start.php";
     
     $query = 'UPDATE tweets SET shared='.safe_get(count).' WHERE tweetnum = \''.safe_get(tweetid).'\';';
     
     $result = pg_query($query) or fail();
     
     
     include "end.php";
?>
