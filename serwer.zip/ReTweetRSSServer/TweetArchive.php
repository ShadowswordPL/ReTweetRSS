<?php

     include "start.php";
     
     $query = 'SELECT 
                * 
               FROM 
               (
                    SELECT 
                        messege.id, user_id 
                    FROM 
                        feed 
                    LEFT JOIN 
                        messege 
                    ON 
                        feed.id = feed_id 
                ) m 
                RIGHT JOIN  
                    tweets 
                ON 
                    m.id = messege_id
                WHERE 
                    user_id = '.$user[id].'
                ORDER BY date DESC
                ;';
     
     $result = pg_query($query) or fail();
     
     echo "<tweets>";
     while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) 
     {
         echo "<tweet>";
         echo "<date>$line[date]</date>";
         echo "<id>$line[tweetnum]</id>";
         echo "<content>$line[content]</content>";
         echo "<shared>$line[shared]</shared>";
         echo "</tweet>";
     }
     echo "</tweets>";
     
     include "end.php";
?>
