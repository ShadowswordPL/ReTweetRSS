<?php
    include "start.php";
   
    $query = 'SELECT * FROM "messege" WHERE link = \''.safe_get("link").'\';';
    $result = pg_query($query) or fail();
    $num = pg_num_rows($result);
    
    if($num == 0)
    {
        $query = 'INSERT INTO "messege"
                   ("feed_id", "date", "title", "content", "link", "short_link")
                   VALUES 
                   (
                       \''.safe_get("feed_id").'\', 
                       current_date,
                       \''.safe_get("title").'\',
                       \''.safe_get("content").'\',
                       \''.safe_get("link").'\',
                       \''.safe_get("short_link").'\'
                    );';
     
        $result = pg_query($query) or die('Nieprawidłowe zapytanie: ' . pg_last_error());
    }
   
    echo "<success>1</success>";
    include "end.php";

?>

