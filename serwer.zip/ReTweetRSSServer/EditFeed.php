<?php
    include "start.php";
    
    if(safe_get("ID") == -1)
    {
       $query = 'INSERT INTO "feed"
                 ("name", "link", "user_id")
                 VALUES 
                 (
                     \''.safe_get("name").'\', 
                     \''.safe_get("link").'\', 
                     '.$user["id"].'
                 );';   
    }
    else
    {
        $query = 'UPDATE "feed"
                  SET 
                    "name" =  \''.safe_get("name").'\',
                    "link" = \''.safe_get("link").'\' 
                  WHERE
                    "id" = '.safe_get("ID").'
                  ;';  
    }
    $result = pg_query($query) or fail();
    echo "<success>1</success>";
    include "end.php";
?>
