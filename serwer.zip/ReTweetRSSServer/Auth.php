<?php

    include "start.php";
    
    $query = 'SELECT * FROM "feed" WHERE "user_id" = '.$user["id"];
    $result = pg_query($query) or fail();
    $feednum = pg_num_rows($result);
    
    $query = 'SELECT * FROM "gloss" LEFT JOIN "usergloss" ON "id" = "gloss_id" WHERE "user_id" = '.$user["id"];
    $result = pg_query($query) or fail();
    $glossesnum = pg_num_rows($result);
    
    $query = 'SELECT 
               count(*) as c, coalesce(sum(shared), 0) as s
              FROM 
              (
                   SELECT 
                       messege.id, user_id 
                   FROM 
                       feed 
                   LEFT JOIN 
                       messege 
                   ON 
                       feed.id = feed_id 
               ) m 
               RIGHT JOIN  
                   tweets 
               ON 
                   m.id = messege_id
               WHERE 
                       user_id = '.$user["id"].';'
                ;
    
    $result = pg_query($query) or fail();
    while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) 
    {
         $sendnum = $line[c];
         $retweetnum = $line[s];
         
     }
    
    $query = 'SELECT * FROM "gloss" LEFT JOIN "usergloss" ON "id" = "gloss_id" WHERE "user_id" = '.$user["id"];
    $result = pg_query($query) or fail();
    $glossesnum = pg_num_rows($result);
    
    echo "<success>1</success>";
    echo "<mood>".$user["mood"]."</mood>";
    echo "<last_number>".$user["last_number"]."</last_number>";        
    echo "<feeds_number>".$feednum."</feeds_number>";        
    echo "<glosses_number>".$glossesnum."</glosses_number>"; 
    echo "<send_number>".$sendnum."</send_number>";        
    echo "<retweet_number>".$retweetnum."</retweet_number>";
    include "end.php";
    
?>
