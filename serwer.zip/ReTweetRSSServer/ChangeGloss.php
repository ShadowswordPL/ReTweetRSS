<?php
    include "start.php";
    
    $query = 'SELECT * FROM "usergloss" WHERE "user_id" = '.$user["id"].' AND "gloss_id" = '.safe_get("GLOSS_ID");
    $result = pg_query($query) or fail();
    $glossnum = pg_num_rows($result);
    
    if($glossnum > 0)
    {
       $query = 'DELETE 
                    FROM "usergloss"
                    WHERE "user_id" = '.$user["id"].' 
                    AND "gloss_id" = '.safe_get("GLOSS_ID").'
                    ;';   
    }
    else
    {
        $query = 'INSERT INTO "usergloss"
                    ("user_id", "gloss_id")
                    VALUES 
                    (
                        \''.$user["id"].'\', 
                        \''.safe_get("GLOSS_ID").'\'
                     );';     
    }
    
    $result = pg_query($query) or fail();
    echo "<success>1</success>";
    include "end.php";
?>
