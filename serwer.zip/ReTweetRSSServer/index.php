<?php
//Może być puste ;)
?>