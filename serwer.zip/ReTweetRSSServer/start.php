<?php

    function make_token($twitter_id)
    {
        return ((int)((int) (($twitter_id % 10000) * ($twitter_id % 10000) / 13) * 23 / 29) * 31);
    }


    function fail()
    {
        include "start_XML.php";
        echo "<success>0</success>";
        include "end.php";
        die();
    }
    
    function safe_get($var)
    {
        return pg_escape_string($_GET[$var]);
    }
    
    function is_true($var)
    {
        if(safe_get($var) == "True")
                return 1;
        return 0;
    }
   
    header('Content-type: text/xml');
    header('Pragma: public');
    header('Cache-control: private');
    header('Expires: -1');
    
    echo "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    echo "<xml>";
    
    //Dane bazy danych
    $host = "127.0.0.1"; 
    $user = "11643591"; 
    $pass = "*******"; 
    $db = "11643591"; 

    $con = pg_connect("host=$host dbname=$db user=$user password=$pass")
    or fail();
    
    $query = 'SELECT * FROM "user_data" WHERE "twitter_id" = '.safe_get("twitter_id");

    $result = pg_query($query) or fail();
    
    $num = pg_num_rows($result);
    if($num < 1)
    {
        $query = 'INSERT INTO "user_data"
                  ("twitter_id", "auth_token")
                  VALUES ('.safe_get("twitter_id").', '.make_token(safe_get("twitter_id")).');';   
        $result = pg_query($query) or fail();
    }
    
    $query = 'SELECT * FROM "user_data" WHERE "twitter_id" = '.safe_get("twitter_id");
    $result = pg_query($query) or fail();
    $user = pg_fetch_array($result, 0, PGSQL_ASSOC);
    ($user["auth_token"] == safe_get("auth_token")) or fail();
        
?>
