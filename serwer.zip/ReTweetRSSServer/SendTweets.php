<?php
    include "start.php";

    $query = 'UPDATE 
                user_data 
              SET 
                mood = '.safe_get("mood").', 
                last_number = '.safe_get("last_number").' 
              WHERE 
                id = '.$user[id].';';
    
    $result = pg_query($query) or fail();
    
    
    $query = 'SELECT addtweets('.$user[id].', 0);';
    $result = pg_query($query) or fail();
    
    
    $query = 'SELECT 
                id, content 
              FROM 
                tweets 
              WHERE 
                messege_id 
              IN 
                (SELECT messege.id FROM feed LEFT JOIN messege ON feed.id = feed_id WHERE user_id = '.$user[id].')
              AND
                send = False;';
    
    $result = pg_query($query) or fail();
    
    echo "<tweets>";
    while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) 
    {
        echo "<tweet>";
        echo "<id>$line[id]</id>";
        echo "<content>$line[content]</content>";
        echo "</tweet>";
    }
    echo "</tweets>";
    
    
    
    include "end.php";

?>
