<?php

include "start.php";

$query = 'UPDATE 
                tweets 
          SET 
            send = True, 
            tweetnum = '.safe_get("tweetnum").' 
          WHERE 
            id = '.safe_get("tweetid").';';
    
    $result = pg_query($query) or fail();
  
include "end.php";
?>
