<?php
    include "start.php";
    
     $query = 'INSERT INTO "gloss"
               ("content", "ispositive")
               VALUES 
               (
                   \''.safe_get("content").'\', 
                   \''.safe_get("isPositive").'\'
                );';   
     
    $result = pg_query($query) or fail();
    echo "<success>1</success>";
    include "end.php";
?>
