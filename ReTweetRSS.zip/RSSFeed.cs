﻿using QDFeedParser;
using $safeprojectname$.Exceptions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Navigation;


namespace $safeprojectname$
{
    public class RSSFeed
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Link { get; set; }

        public RSSFeed()
        {
            ID = -1;
            Name = "Empty";
            Link = "Empty";
        }

        public RSSFeed(int ID, string Name, string Link)
        {
            this.ID = ID;
            this.Name = Name;
            this.Link = Link;
        }

        static public async Task<bool> ValidateFeed(string link)
        {
            Uri feeduri;
            HttpFeedFactory factory = new HttpFeedFactory();
            return Uri.TryCreate(link, UriKind.Absolute, out feeduri) && "http://".Equals(link.Substring(0, 7)) && await factory.PingFeedAsync(feeduri);
        }

        public async Task SendFeed()
        {
            Uri feeduri;
            HttpFeedFactory factory = new HttpFeedFactory();
            if (Uri.TryCreate(Link, UriKind.Absolute, out feeduri) && "http://".Equals(Link.Substring(0, 7)) && await factory.PingFeedAsync(feeduri))
            {
                IFeed feed = await factory.CreateFeedAsync(feeduri);

                foreach (var feedItem in feed.Items)
                {
                    string s = string.Empty;

                    s += "&feed_id=" + ID;
                    s += "&date=" + feedItem.DatePublished;
                    s += "&title=" + feedItem.Title;
                    s += "&link=" + feedItem.Link;
                    s += "&content=" + Regex.Replace(feedItem.Content, "<.*?>", string.Empty).Replace("  ", string.Empty);
                    s += "&short_link=" + await UserData.ShortUrl(feedItem.Link);

                    String xml = await UserData.Connect("AddMesseges", s);

                    if (UserData.XML_readint(xml, "success") != 1)
                    {
                        MessageBox.Show("Unknown error, try agian.");
                        return;
                    }
                }
            }
        }

    }
}
