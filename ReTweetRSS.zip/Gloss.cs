﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace $safeprojectname$
{
    public class Gloss
    {
        public int ID { get; set; }
        public string content { get; set; }
        public int usedby { get; set; }
        public SolidColorBrush color { get; set; }
        public string SelectedTxt { get; set; }

        private bool ispositive;
        public bool isPositive 
        { 
            get {return ispositive;} 
            set 
            { 
                ispositive = value;
                if(ispositive)
                {
                    color = new SolidColorBrush(Colors.Green);
                }
                else
                {
                    color = new SolidColorBrush(Colors.Red);
                }
            } 
        }

        private bool selected;
        public bool Selected
        {
            get { return selected; }
            set
            {
                selected= value;
                if (selected)
                {
                    SelectedTxt = "Selected";
                }
                else
                {
                    SelectedTxt = "Unselected";
                }
            }
        }

        public Gloss()
        {
            ID = -1;
            content = "";
            isPositive = true;
            Selected = false;
            usedby = 0;
        }

        public Gloss(int ID, string content, bool isPositive, int usedby)
        {
            this.ID = ID;
            this.content = content;
            this.isPositive = isPositive;
            this.usedby = usedby;
        }
    }
}
