﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace $safeprojectname$
{
    public class AppSettings
    {
        // twitter
        public static string RequestTokenUri = "https://api.twitter.com/oauth/request_token";
        public static string AuthorizeUri = "https://api.twitter.com/oauth/authorize";
        public static string AccessTokenUri = "https://api.twitter.com/oauth/access_token";
        public static string CallbackUri = "http://www.google.com";

        public static string consumerKey = "0EoDpYaTykCKy7fHjpu0XQ";
        public static string consumerKeySecret = "z7jYBSN1mcKhkK0rM8e6hk05Ck58nKAd2TSdybRjls";

        public static string oAuthVersion = "1.0a";
    }
}
