﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class Tweet
    {
        public string date { get; set; }
        public string content { get; set; }
        public int shared { get; set; }
        public string id { get; set; }

        public Tweet() { date = ""; content = ""; shared = 0; id = ""; }
    }
}
