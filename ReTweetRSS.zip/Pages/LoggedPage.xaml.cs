﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using System.Windows.Media;
using System.Text;
using TweetSharp;
using System.Xml;
using System.IO;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using System.Threading;

namespace $safeprojectname$
{
    public partial class LoggedPage : PhoneApplicationPage
    {
        public LoggedPage()
        {
            InitializeComponent();
            Data_Reload();
            Username.Text = MainUtil.GetKeyValue<string>("ScreenName");
        }

        private void Edit_RSS_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/RSSListPage.xaml", UriKind.Relative));
        }

        private void Archive_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/TweetArchivePage.xaml", UriKind.Relative));
        }

        private void Edit_Gloss_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/GlossListPage.xaml", UriKind.Relative));
        }

        private void SetMood()
        {
            App.Current.userdata.Mood = Convert.ToInt32(Math.Round(MoodSlider.Value));
            String s = "";
            SolidColorBrush c = new SolidColorBrush();
            switch (App.Current.userdata.Mood)
            {
                case 1:
                    c = new SolidColorBrush(Colors.Red);
                    s = "Furious";
                    break;
                case 2:
                    c = new SolidColorBrush(Colors.Gray);
                    s = "Angry";
                    break;
                case 3:
                    c = new SolidColorBrush(Colors.LightGray);
                    s = "Neutral";
                    break;
                case 4:
                    c = new SolidColorBrush(Colors.White);
                    s = "Happy";
                    break;
                case 5:
                    c = new SolidColorBrush(Colors.Green);
                    s = "Jubilant";
                    break;
            }
            MoodText.Foreground = c;
            MoodText.Text = s;
        }

        void SetNumber()
        {
            App.Current.userdata.Last_number = Convert.ToInt32(Math.Round(NumberSlider.Value));
            NumberText.Text = App.Current.userdata.Last_number.ToString();
        }

        private void Data_Reload()
        {
            RetweetsNumField.Text = App.Current.userdata.RetweetNum.ToString();
            SendNumField.Text = App.Current.userdata.SendNum.ToString();
            FeedNumField.Text = App.Current.userdata.FeedNum.ToString();
            GlossNumField.Text = App.Current.userdata.GlossNum.ToString();
            MoodSlider.Value = App.Current.userdata.Mood;
            SetMood();
            NumberSlider.Value = App.Current.userdata.Last_number;
            SetNumber();
        }

        private void Log_out_Click(object sender, RoutedEventArgs e)
        {
            MainUtil.SetKeyValue<string>("AccessToken", string.Empty);
            MainUtil.SetKeyValue<string>("AccessTokenSecret", string.Empty);

            Dispatcher.BeginInvoke(() =>
            {
                MessageBox.Show("You have been logged out successfully.");
            });

            NavigationService.Navigate(new Uri("/Pages/MainPage.xaml", UriKind.Relative));
            while (this.NavigationService.BackStack.Any())
            {
                this.NavigationService.RemoveBackEntry();
            }
        }

        private void MoodSlider_ManipulationCompleted(object sender, System.Windows.Input.ManipulationCompletedEventArgs e)
        {
            SetMood();
        }

        private void NumberSlider_ManipulationCompleted(object sender, System.Windows.Input.ManipulationCompletedEventArgs e)
        {
            SetNumber();
        }

        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            Bar.Visibility = Visibility.Visible;
            await App.Current.userdata.Refresh();
            Data_Reload();
            Bar.Visibility = Visibility.Collapsed;
        }

        private async Task sTweet(TwitterService service, int id, string s)
        {
            service.SendTweet(new SendTweetOptions { Status = s }, async (tweet, response) =>
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    JObject o = JObject.Parse(response.Response);
                    string tweetnum = (string)o["id"];
                    await UserData.Connect("TweetOK", "&tweetid=" + id.ToString() + "&tweetnum=" + tweetnum);
                }
            });
        }

        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            if(App.Current.userdata.FeedNum == 0 || App.Current.userdata.GlossNum == 0) 
            {
                MessageBox.Show("U need at least one feed and one gloss to send tweets!");
            }
            else
            {
            
                Bar.Visibility = Visibility.Visible;
                await App.Current.userdata.UpdateFeeds();
                foreach (RSSFeed f in App.Current.userdata.Feeds)
                {
                    await f.SendFeed();
                }

                String xml = await UserData.Connect("SendTweets", "&mood=" + App.Current.userdata.Mood + "&last_number=" + App.Current.userdata.Last_number);

                XmlReader r = XmlReader.Create(new StringReader(xml));

                int id = 0;
                string s;
            
                TwitterService service = new TwitterService(AppSettings.consumerKey, AppSettings.consumerKeySecret);
                service.AuthenticateWith(App.Current.userdata.accessToken, App.Current.userdata.accessTokenSecret);

                while (r.Read())
                {
                    if (r.Name.Equals("id") && (r.NodeType == XmlNodeType.Element))
                    {
                        id = r.ReadElementContentAsInt();
                    }

                    if (r.Name.Equals("content") && (r.NodeType == XmlNodeType.Element))
                    {
                        s = r.ReadElementContentAsString();
                        await sTweet(service, id, s);               
                    }
       
                }
            
                MessageBox.Show("Tweets send sucessfuly.");
                Bar.Visibility = Visibility.Collapsed;
            }
        }
    }
}