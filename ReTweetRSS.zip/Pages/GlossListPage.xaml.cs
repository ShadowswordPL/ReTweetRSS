﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using QDFeedParser;
using $safeprojectname$.Exceptions;


namespace $safeprojectname$.Pages
{
    public partial class GlossListPage : PhoneApplicationPage
    {
        String s;
        bool button;
        string last_value;
        
        public GlossListPage()
        {
            InitializeComponent();
            DownloadGlosses();
            button = false;
            last_value = "";
        }

        private async void DownloadGlosses()
        {
            string s = (sorted.SelectedItem as TextBlock).Text;
            await App.Current.userdata.UpdateGlosses((bool)PositiveBox.IsChecked, (bool)NegativeBox.IsChecked, (sorted.SelectedItem as TextBlock).Text);
            this.MainLongListSelector.ItemsSource = GetGlosses();
            Bar.Visibility = Visibility.Collapsed;
            ContentPanel.Visibility = Visibility.Visible;
        }


        private async void MainLongListSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (button)
            {
                button = false;
                Microsoft.Phone.Controls.LongListSelector selector = (Microsoft.Phone.Controls.LongListSelector)sender;
                // If selected item is null (no selection) do nothing
                if (MainLongListSelector.SelectedItem == null)
                    return;

                // Navigate to the new page
                String xml = await UserData.Connect("ChangeGloss", "&GLOSS_ID=" + (selector.SelectedItem as Gloss).ID);

                if (UserData.XML_readint(xml, "success") == 1)
                {
                    NavigationService.Navigate(new Uri("/Pages/GlossListPage.xaml?" + DateTime.Now.Ticks, UriKind.Relative));
                }
                else
                {
                    MessageBox.Show("Unknown error, try agian.");
                }

                // Reset selected item to null (no selection)
            }
            MainLongListSelector.SelectedItem = null;
        }

        private static List<List<Gloss>> GetGlosses()
        {
            List<List<Gloss>> GlossesGroup = new List<List<Gloss>>();
            List<Gloss> Glosses = App.Current.userdata.Glosses;
            
            GlossesGroup.Add(Glosses);

            return GlossesGroup;
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/LoggedPage.xaml", UriKind.Relative));
        }

        private void AddFeedButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/AddGlossPage.xaml", UriKind.Relative));
        }

        private void ChooseGlossButton_Click(object sender, RoutedEventArgs e)
        {
            button = true;         
        }

        private void Updated_Tap(object sender, System.Windows.Input.GestureEventArgs e)
        {

            DownloadGlosses();
        }

        private void sorted_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (sorted != null && last_value != (sorted.SelectedItem as TextBlock).Text)
            {
                last_value = (sorted.SelectedItem as TextBlock).Text;
                DownloadGlosses();
            }
        }

    }
}