﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace $safeprojectname$.Pages
{
    public partial class AddGlossPage : PhoneApplicationPage
    {
        int page_id;

        public AddGlossPage()
        {
            InitializeComponent();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/GlossListPage.xaml", UriKind.Relative));
        }

        private async void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (ContentBox.Text.Length > 120)
            {
                MessageBox.Show("Content is too long.");
            }
            else if (ContentBox.Text.Length < 10)
            {
                MessageBox.Show("Content must have at least 10 chars.");
            }
            else
            {
                int ispositive;
                if (PositiveButton.IsChecked ?? true)
                {
                    ispositive = 1;
                }
                else
                {
                    ispositive = 0;
                }
                String xml = await UserData.Connect("AddGloss", "&content=" + ContentBox.Text + "&isPositive=" + ispositive.ToString());

                if (UserData.XML_readint(xml, "success") == 1)
                {
                    MessageBox.Show("Gloss saved sucessfully");
                    NavigationService.Navigate(new Uri("/Pages/GlossListPage.xaml", UriKind.Relative));
                }
                else
                {
                    MessageBox.Show("Unknown error, try agian.");
                }
            }
        }
 
    }
}