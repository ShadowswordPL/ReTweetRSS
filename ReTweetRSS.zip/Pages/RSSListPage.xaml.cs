﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using QDFeedParser;
using $safeprojectname$.Exceptions;


namespace $safeprojectname$.Pages
{
    public partial class RSSList : PhoneApplicationPage
    {
        String s;
        bool delete;
    
        public RSSList()
        {
            delete = false;
            InitializeComponent();
            DownloadFeeds();
        }

        private async void DownloadFeeds()
        {
            await App.Current.userdata.UpdateFeeds();
            this.MainLongListSelector.ItemsSource = GetFeeds();
            Bar.Visibility = Visibility.Collapsed;
            ContentPanel.Visibility = Visibility.Visible;
        }


        private async void MainLongListSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Microsoft.Phone.Controls.LongListSelector selector = (Microsoft.Phone.Controls.LongListSelector)sender;
            // If selected item is null (no selection) do nothing
            if (MainLongListSelector.SelectedItem == null)
                return;

            if (delete)
            {
                delete = false;
                MessageBoxResult m = MessageBox.Show("Deleting of feed is irreversible, are You sure?", "cancel", MessageBoxButton.OKCancel);
                if (m == MessageBoxResult.OK)
                {
                    String xml = await UserData.Connect("DeleteFeed", "&ID=" + (selector.SelectedItem as RSSFeed).ID);
                    if (UserData.XML_readint(xml, "success") == 1)
                    {
                        MessageBox.Show("Feed " + (selector.SelectedItem as RSSFeed).Name + " removed sucessfully");
                        NavigationService.Navigate(new Uri("/Pages/RSSListPage.xaml?" + DateTime.Now.Ticks, UriKind.Relative));
                    }
                    else
                    {
                        MessageBox.Show("Cannot delete feed, try agian.");
                    }
                }
            }
            else
            {
                // Navigate to the new page
                NavigationService.Navigate(new Uri("/Pages/EditFeedPage.xaml?id=" + (selector.SelectedItem as RSSFeed).ID, UriKind.Relative));
            }

            // Reset selected item to null (no selection)
            MainLongListSelector.SelectedItem = null;
        }

        private static List<List<RSSFeed>> GetFeeds()
        {
            List<List<RSSFeed>> FeedsGroup = new List<List<RSSFeed>>();
            List<RSSFeed> Feeds = App.Current.userdata.Feeds;
            
            FeedsGroup.Add(Feeds);

            return FeedsGroup;
        }

        protected override void OnBackKeyPress(System.ComponentModel.CancelEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/LoggedPage.xaml", UriKind.Relative));
        }

        private void AddFeedButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/EditFeedPage.xaml?id=-1", UriKind.Relative));
        }

        private void RemoveFeedButton_Click(object sender, RoutedEventArgs e)
        {
            delete = true;
        }
    }
}