﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using QDFeedParser;
using $safeprojectname$.Exceptions;


namespace $safeprojectname$.Pages
{
    public partial class TweetArchivePage : PhoneApplicationPage
    {
        
        public TweetArchivePage()
        {
            InitializeComponent();
            DownloadTweets();
        }

        private async void DownloadTweets()
        {
            await App.Current.userdata.UpdateTweets();
            this.MainLongListSelector.ItemsSource = GetTweets();
            Bar.Visibility = Visibility.Collapsed;
            ContentPanel.Visibility = Visibility.Visible;
        }



        private static List<List<Tweet>> GetTweets()
        {
            List<List<Tweet>> TweetsGroup = new List<List<Tweet>>();
            List<Tweet> Tweets = App.Current.userdata.Tweets;
            
            TweetsGroup.Add(Tweets);

            return TweetsGroup;
        }

       
    }
}