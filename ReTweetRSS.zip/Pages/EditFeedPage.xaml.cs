﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace $safeprojectname$.Pages
{
    public partial class EditFeedPage : PhoneApplicationPage
    {
        int page_id;

        public EditFeedPage()
        {
            InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            base.OnNavigatedTo(e);
            page_id = Convert.ToInt32(NavigationContext.QueryString["id"]);
            
            if (page_id != -1)
            {
                RSSFeed current = App.Current.userdata.Feeds.Find(x => x.ID == page_id);
                NameBox.Text = current.Name;
                LinkBox.Text = current.Link;
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Uri("/Pages/RSSListPage.xaml", UriKind.Relative));
        }

        private async void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (await RSSFeed.ValidateFeed(LinkBox.Text))
            {
                String xml = await UserData.Connect("EditFeed", "&ID=" + page_id + "&name=" + NameBox.Text + "&link=" + LinkBox.Text);
                if (UserData.XML_readint(xml, "success") == 1)
                {
                    MessageBox.Show("Feed " + NameBox.Text + " saved sucessfully");
                    NavigationService.Navigate(new Uri("/Pages/RSSListPage.xaml", UriKind.Relative));
                }
                else
                {
                    MessageBox.Show("Unknown error, try agian.");
                }
            }
            else
            {
                MessageBox.Show("Unsupported feed format. We cannot add this feed.");
            }
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            LinkBox.Text = "";
        }

    }
}