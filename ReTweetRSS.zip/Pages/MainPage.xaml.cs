﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using Hammock.Web;
using System.IO;
using Hammock;
using System.Text;
using Hammock.Authentication.OAuth;

namespace $safeprojectname$
{
    public partial class MainPage : PhoneApplicationPage
    {
              
        // Constructor
        public MainPage()
        {
            InitializeComponent();
            if (isAlreadyLoggedIn())
            {
                userLoggedIn();
            }
        }

        private Boolean isAlreadyLoggedIn()
        {
            App.Current.userdata.accessToken = MainUtil.GetKeyValue<string>("AccessToken");
            App.Current.userdata.accessTokenSecret = MainUtil.GetKeyValue<string>("AccessTokenSecret");

            if (string.IsNullOrEmpty(App.Current.userdata.accessToken) || string.IsNullOrEmpty(App.Current.userdata.accessTokenSecret))
                return false;
            else
                return true;
        }

        private async void userLoggedIn()
        {
            if (await App.Current.userdata.login())
            {
                this.NavigationService.Navigate(new Uri("/Pages/LoggedPage.xaml", UriKind.Relative));
                while (this.NavigationService.BackStack.Any())
                {
                    this.NavigationService.RemoveBackEntry();
                }
            }
            else
            {
                MessageBox.Show("Error in login, try again.");
            }
        }

        
        void requestTokenQuery_QueryResponse(object sender, WebQueryResponseEventArgs e)
        {
            try
            {
                StreamReader reader = new StreamReader(e.Response);
                string strResponse = reader.ReadToEnd();
                var parameters = MainUtil.GetQueryParameters(strResponse);
                App.Current.userdata.OAuthTokenKey = parameters["oauth_token"];
                App.Current.userdata.tokenSecret = parameters["oauth_token_secret"];
                var authorizeUrl = AppSettings.AuthorizeUri + "?oauth_token=" + App.Current.userdata.OAuthTokenKey;

                Dispatcher.BeginInvoke(() =>
                {
                    loginBrowserControl.Navigate(new Uri(authorizeUrl, UriKind.RelativeOrAbsolute));
                });
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(() =>
                {
                    MessageBox.Show(ex.Message);
                });
            }
        }

        private void loginBrowserControl_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            this.loginBrowserControl.Visibility = Visibility.Visible;
            this.loginBrowserControl.Navigated -= loginBrowserControl_Navigated;
        }

        private void loginBrowserControl_Navigating(object sender, NavigatingEventArgs e)
        {
            if (e.Uri.ToString().StartsWith(AppSettings.CallbackUri))
            {
                var AuthorizeResult = MainUtil.GetQueryParameters(e.Uri.ToString());
                var VerifyPin = AuthorizeResult["oauth_verifier"];
                this.loginBrowserControl.Visibility = Visibility.Collapsed;
                var AccessTokenQuery = OAuthUtil.GetAccessTokenQuery(App.Current.userdata.OAuthTokenKey, App.Current.userdata.tokenSecret, VerifyPin);

                AccessTokenQuery.QueryResponse += new EventHandler<WebQueryResponseEventArgs>(AccessTokenQuery_QueryResponse);
                AccessTokenQuery.RequestAsync(AppSettings.AccessTokenUri, null);
            }
        }

        void AccessTokenQuery_QueryResponse(object sender, WebQueryResponseEventArgs e)
        {
            try
            {
                StreamReader reader = new StreamReader(e.Response);
                string strResponse = reader.ReadToEnd();
                var parameters = MainUtil.GetQueryParameters(strResponse);
                App.Current.userdata.accessToken = parameters["oauth_token"];
                App.Current.userdata.accessTokenSecret = parameters["oauth_token_secret"];

                MainUtil.SetKeyValue<string>("AccessToken", App.Current.userdata.accessToken);
                MainUtil.SetKeyValue<string>("AccessTokenSecret", App.Current.userdata.accessTokenSecret);
                MainUtil.SetKeyValue<string>("ScreenName", parameters["screen_name"]);
                MainUtil.SetKeyValue<string>("TwitterID", parameters["user_id"]);

                Dispatcher.BeginInvoke(() =>
                {
                    NavigationService.Navigate(new Uri("/Pages/MainPage.xaml?" + DateTime.Now.Ticks, UriKind.Relative));
                });
            }
            catch (Exception ex)
            {
                Dispatcher.BeginInvoke(() =>
                {
                    MessageBox.Show(ex.Message);
                });
            }

        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            Bar.Visibility = Visibility.Visible;
            var requestTokenQuery = OAuthUtil.GetRequestTokenQuery();
            requestTokenQuery.RequestAsync(AppSettings.RequestTokenUri, null);
            requestTokenQuery.QueryResponse += new EventHandler<WebQueryResponseEventArgs>(requestTokenQuery_QueryResponse);          
        }
    }

}