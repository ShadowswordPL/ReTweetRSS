﻿using Google.Apis.Services;
using Google.Apis.Urlshortener.v1;
using Google.Apis.Urlshortener.v1.Data;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using System.Xml;
using TweetSharp;

namespace $safeprojectname$
{
    public class UserData
    {
        public string OAuthTokenKey = string.Empty;
        public string tokenSecret = string.Empty;
        public string accessToken = string.Empty;
        public string accessTokenSecret = string.Empty;

        public int FeedNum {get; set;}
        public int GlossNum {get; set; }
        public int RetweetNum { get; set; }
        public int SendNum { get; set; }

        public int Mood { get; set; }
        public int Last_number { get; set; }
        
        public List<RSSFeed> Feeds;
        public List<Gloss> Glosses;
        public List<Tweet> Tweets;

        public UserData()
        {
            Mood = -1;
            FeedNum = -1;
            GlossNum = -1;
            Last_number = -1;
            SendNum = -1;
            RetweetNum = -1;
            Feeds = new List<RSSFeed>();
            Glosses = new List<Gloss>();
            Tweets = new List<Tweet>();
        }

        static long make_token(long twitter_id)
        {
            return ((twitter_id % 10000) * (twitter_id % 10000) / 13 * 23 / 29 * 31);
        }

        public async Task Refresh()
        {
            await login();
            await UpdateFeeds();
            await UpdateTweets();
        }

        public static int XML_readint(string source, string attr)
        {
            try
            {
                XmlReader r = XmlReader.Create(new StringReader(source));
                r.ReadToFollowing(attr);
                return r.ReadElementContentAsInt();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return 0;
        }

        public static async Task<string> Connect(String adress)
        {
            return await Connect(adress, "");
        }

        public static async Task<String> Connect(String adress, String additional)
        {
            string y = MainUtil.GetKeyValue<string>("TwitterID");
            y = Convert.ToInt64(MainUtil.GetKeyValue<string>("TwitterID")).ToString();
            y = make_token(Convert.ToInt64(MainUtil.GetKeyValue<string>("TwitterID"))).ToString();
            Uri s = new Uri("http://lomies.home.pl/bd/ServerReTweetRSS/"+adress+".php?twitter_id="+
                            MainUtil.GetKeyValue<string>("TwitterID") +
                            "&auth_token=" +
                            make_token(Convert.ToInt64(MainUtil.GetKeyValue<string>("TwitterID"))).ToString() +
                            additional
                            );
            HttpClient hc = new HttpClient();
            return await hc.GetStringAsync(s);

        }

        public async Task<bool> login()
        {
            String xml = await Connect("Auth");

            if (XML_readint(xml, "success") == 1)
            {
                Mood = XML_readint(xml, "mood");
                Last_number = XML_readint(xml, "last_number");
                FeedNum = XML_readint(xml, "feeds_number");
                GlossNum = XML_readint(xml, "glosses_number");
                SendNum = XML_readint(xml, "send_number");
                RetweetNum = XML_readint(xml, "retweet_number");
                return true;
            }

            return false;
        }

        static public async Task<string> ShortUrl(string longlink)
        {
            UrlshortenerService service = new UrlshortenerService(new BaseClientService.Initializer
            {
                ApplicationName = "$safeprojectname$",
            });

            Url response = await service.Url.Insert(new Url { LongUrl = longlink }).ExecuteAsync();

            // Display response
            return response.Id;
        }

        public async Task UpdateFeeds()
        {
            String xml = await Connect("Feeds");

            XmlReader r = XmlReader.Create(new StringReader(xml));

            RSSFeed f = new RSSFeed();
            Feeds.Clear();
            while (r.Read())
            {
                if (r.Name.Equals("feed") && (r.NodeType == XmlNodeType.Element))
                {
                    f = new RSSFeed();
                }

                if (r.Name.Equals("id") && (r.NodeType == XmlNodeType.Element))
                {
                    f.ID = r.ReadElementContentAsInt();
                }

                if (r.Name.Equals("name") && (r.NodeType == XmlNodeType.Element))
                {
                    f.Name = r.ReadElementContentAsString();
                }

                if (r.Name.Equals("link") && (r.NodeType == XmlNodeType.Element))
                {
                    f.Link = r.ReadElementContentAsString();
                    Feeds.Add(f);
                }
            }
        }

        public async Task UpdateGlosses(bool positive, bool negative, string sorted)
        {
            String sort = "";
            if(sorted == "inc. popularity")
                sort = "popasc";
            else if (sorted == "dec. popularity")
                sort = "popdesc";
            else if (sorted == "inc. alphabetical")
                sort = "alpasc";
            else if (sorted == "dec. alphabetical")
                sort = "alpdesc";
            
            String xml = await Connect("Glosses", "&positive="+positive.ToString()+"&negative="+negative.ToString()+"&sort="+sort);

            XmlReader r = XmlReader.Create(new StringReader(xml));

            Gloss f = new Gloss();
            Glosses.Clear();
            while (r.Read())
            {
                if (r.Name.Equals("gloss") && (r.NodeType == XmlNodeType.Element))
                {
                    f = new Gloss();
                }

                if (r.Name.Equals("id") && (r.NodeType == XmlNodeType.Element))
                {
                    f.ID = r.ReadElementContentAsInt();
                }

                if (r.Name.Equals("content") && (r.NodeType == XmlNodeType.Element))
                {
                    f.content = r.ReadElementContentAsString();
                }

                if (r.Name.Equals("isPositive") && (r.NodeType == XmlNodeType.Element))
                {
                    f.isPositive = Convert.ToBoolean(r.ReadElementContentAsInt());
                }

                if (r.Name.Equals("selected") && (r.NodeType == XmlNodeType.Element))
                {
                    f.Selected = Convert.ToBoolean(r.ReadElementContentAsInt());
                }

                if (r.Name.Equals("usedby") && (r.NodeType == XmlNodeType.Element))
                {
                    f.usedby = r.ReadElementContentAsInt();
                    Glosses.Add(f);
                }
            }
        }

        private async Task UpdateReTweet(TwitterService service, String num)
        {
            service.GetTweet(new GetTweetOptions{ Id = Convert.ToInt64(num)}, async (tweet, response) =>
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    JObject o = null;
                    try
                    {
                        o = JObject.Parse(response.Response);
                    }
                    catch (Exception e)
                    {
                        return;
                    }
                        string count = (string)o["retweet_count"];
                    await UserData.Connect("RetweetCount", "&tweetid=" + num + "&count=" + count);
                }
            }); 
        }

        public async Task UpdateTweets()
        {
            String xml = await Connect("TweetArchive");

            XmlReader r = XmlReader.Create(new StringReader(xml));

            Tweet t = new Tweet();
            Tweets.Clear();
            while (r.Read())
            {
                if (r.Name.Equals("date") && (r.NodeType == XmlNodeType.Element))
                {
                    t = new Tweet();
                    t.date = r.ReadElementContentAsString();
                }

                if (r.Name.Equals("id") && (r.NodeType == XmlNodeType.Element))
                {
                    t.id = r.ReadElementContentAsString();
                }

                if (r.Name.Equals("content") && (r.NodeType == XmlNodeType.Element))
                {
                    t.content = r.ReadElementContentAsString();
                }

                if (r.Name.Equals("shared") && (r.NodeType == XmlNodeType.Element))
                {
                    t.shared = r.ReadElementContentAsInt();
                    Tweets.Add(t);
                }
            }

            if (Tweets.Count() > 0)
            {
                Random rnd = new Random();
                TwitterService service = new TwitterService(AppSettings.consumerKey, AppSettings.consumerKeySecret);
                service.AuthenticateWith(App.Current.userdata.accessToken, App.Current.userdata.accessTokenSecret);

                for (int i = 0; i < 10; i++)
                {
                    Tweet s = Tweets[rnd.Next(Tweets.Count)];
                    await UpdateReTweet(service, s.id);
                }
            }
        }
    }
}
