﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;


namespace $safeprojectname$.Exceptions
{
    class FeedsException : Exception
    {
        public void handle()
        {
            MessageBox.Show("Error in connection with list of feeds.");
        }
    }
}
